import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-dieta',
  templateUrl: './registrar-dieta.page.html',
  styleUrls: ['./registrar-dieta.page.scss'],
})
export class RegistrarDietaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
