import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-evolucao',
  templateUrl: './evolucao.page.html',
  styleUrls: ['./evolucao.page.scss'],
})
export class EvolucaoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
