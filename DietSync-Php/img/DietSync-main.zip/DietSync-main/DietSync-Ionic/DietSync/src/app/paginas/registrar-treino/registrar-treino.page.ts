import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registrar-treino',
  templateUrl: './registrar-treino.page.html',
  styleUrls: ['./registrar-treino.page.scss'],
})
export class RegistrarTreinoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
